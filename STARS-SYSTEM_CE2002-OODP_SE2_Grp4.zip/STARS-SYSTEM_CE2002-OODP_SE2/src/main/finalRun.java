package main;
import displayIO.*; 

public class finalRun {
	@SuppressWarnings("unused")
	public static void main(String args[]) {
		loginPage page = new loginPage();
	}
}
